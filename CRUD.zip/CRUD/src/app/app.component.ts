import { Component } from '@angular/core';
import { AppEmployeeComponent } from './app.employeecomponent';
@Component({
  selector: 'my-app',
  templateUrl: './app.component.html'
})
export class AppComponent  
{ 
	

}
